using Dalamud.Configuration;

namespace DmuTankHelper;

public enum RaidRole
{
    Unset,
    MainTank,
    OffTank,
    Healer1,
    Healer2,
    Dps1,
    Dps2,
    Dps3,
    Dps4,
}

[System.Serializable]
public sealed class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 2;
    // MT and OT intentionally retain numeric values 1 and 2 so v1 configs migrate automatically.
    public RaidRole Assignment { get; set; } = RaidRole.Unset;
    public bool ResponsibleForLb3 { get; set; } = true;
    public bool Locked { get; set; }
    public bool HideWhenIdle { get; set; } = true;
    public bool ShowHistory { get; set; } = true;
    public bool EnablePullTimer { get; set; } = true;
    public float PullWarningSeconds { get; set; } = 474f;
    public float TextScale { get; set; } = 1.35f;
    public float BackgroundOpacity { get; set; } = 0.82f;

    public void Save() => Plugin.PluginInterface.SavePluginConfig(this);
}
