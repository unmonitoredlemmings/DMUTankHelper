using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace DmuTankHelper.Windows;

public sealed class ConfigWindow : Window
{
    private readonly Plugin plugin;
    private readonly Configuration config;

    public ConfigWindow(Plugin plugin) : base("DMU Tank Helper Settings###DmuTankHelperConfig")
    {
        this.plugin = plugin;
        config = plugin.Configuration;
        Size = new Vector2(480, 490);
        SizeCondition = ImGuiCond.FirstUseEver;
    }

    public override void Draw()
    {
        ImGui.TextWrapped("MUR/OCE Tank LB3 — Bowels of Agony (Exdeath Mid)");
        ImGui.Separator();
        ImGui.Text("Tank assignment");
        if (ImGui.RadioButton("Main Tank — Chaos / hit 1", config.Assignment == TankAssignment.MainTank)) { config.Assignment = TankAssignment.MainTank; config.ResponsibleForLb3 = true; Save(); }
        if (ImGui.RadioButton("Off Tank — Exdeath / hit 2", config.Assignment == TankAssignment.OffTank)) { config.Assignment = TankAssignment.OffTank; config.ResponsibleForLb3 = false; Save(); }
        ImGui.Spacing();

        var lb3 = config.ResponsibleForLb3;
        if (ImGui.Checkbox("I am responsible for Tank LB3", ref lb3)) { config.ResponsibleForLb3 = lb3; Save(); }
        var locked = config.Locked;
        if (ImGui.Checkbox("Lock overlay (click-through)", ref locked)) { config.Locked = locked; Save(); }
        var hide = config.HideWhenIdle;
        if (ImGui.Checkbox("Hide overlay when idle", ref hide)) { config.HideWhenIdle = hide; Save(); }
        var history = config.ShowHistory;
        if (ImGui.Checkbox("Show callout history here", ref history)) { config.ShowHistory = history; Save(); }
        var timer = config.EnablePullTimer;
        if (ImGui.Checkbox("Enable 7:54 pull-timer fallback", ref timer)) { config.EnablePullTimer = timer; Save(); }

        var scale = config.TextScale;
        if (ImGui.SliderFloat("Text scale", ref scale, 0.8f, 2.5f, "%.2f")) { config.TextScale = scale; Save(); }
        var opacity = config.BackgroundOpacity;
        if (ImGui.SliderFloat("Background opacity", ref opacity, 0.1f, 1f, "%.2f")) { config.BackgroundOpacity = opacity; Save(); }

        ImGui.Spacing();
        if (ImGui.Button("Preview overlay")) plugin.Engine.Set(config.Assignment == TankAssignment.OffTank ? "TAKE HIT 2" : "GO TO EXDEATH", config.Assignment == TankAssignment.OffTank ? "MOVE CLOSEST AFTER HIT 1" : "RAMPART + CAMO + CORUNDUM", 15);
        ImGui.SameLine();
        if (ImGui.Button("Clear now")) plugin.Engine.Reset();
        ImGui.SameLine();
        if (ImGui.Button("Unlock overlay")) { config.Locked = false; Save(); }

        ImGui.Separator();
        ImGui.TextWrapped("Commands: /dmuhelper, /dmuhelper test, /dmuclear");
        ImGui.TextDisabled($"Diagnostic: {plugin.Engine.Diagnostic}");
        if (config.ShowHistory)
        {
            ImGui.Text("Recent callouts:");
            foreach (var line in plugin.Engine.History) ImGui.BulletText(line);
        }
        ImGui.Spacing();
        ImGui.TextWrapped("This plugin never moves your character, presses actions, places markers, or sends game inputs.");
    }

    private void Save() => config.Save();
}
