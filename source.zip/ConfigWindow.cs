using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace DmuTankHelper.Windows;

public sealed class ConfigWindow : Window
{
    private readonly Plugin plugin;
    private readonly Configuration config;

    public ConfigWindow(Plugin plugin) : base("DMU Tank Helper Settings###DmuTankHelperConfig")
    {
        this.plugin = plugin;
        config = plugin.Configuration;
        Size = new Vector2(480, 490);
        SizeCondition = ImGuiCond.FirstUseEver;
    }

    public override void Draw()
    {
        ImGui.TextWrapped("MUR/OCE — Bowels of Agony (Exdeath Mid)");
        ImGui.Separator();
        ImGui.Text("Raid role");
        var currentRole = RoleLabel(config.Assignment);
        if (ImGui.BeginCombo("##RaidRole", currentRole))
        {
            foreach (var role in Enum.GetValues<RaidRole>())
            {
                if (role == RaidRole.Unset) continue;
                var selected = config.Assignment == role;
                if (ImGui.Selectable(RoleLabel(role), selected))
                {
                    config.Assignment = role;
                    if (role == RaidRole.MainTank) config.ResponsibleForLb3 = true;
                    else if (role != RaidRole.OffTank) config.ResponsibleForLb3 = false;
                    Save();
                }
                if (selected) ImGui.SetItemDefaultFocus();
            }
            ImGui.EndCombo();
        }
        ImGui.Spacing();

        if (config.Assignment is RaidRole.MainTank or RaidRole.OffTank)
        {
            var lb3 = config.ResponsibleForLb3;
            if (ImGui.Checkbox("I am responsible for Tank LB3", ref lb3)) { config.ResponsibleForLb3 = lb3; Save(); }
        }
        var locked = config.Locked;
        if (ImGui.Checkbox("Lock overlay (click-through)", ref locked)) { config.Locked = locked; Save(); }
        var hide = config.HideWhenIdle;
        if (ImGui.Checkbox("Hide overlay when idle", ref hide)) { config.HideWhenIdle = hide; Save(); }
        var history = config.ShowHistory;
        if (ImGui.Checkbox("Show callout history here", ref history)) { config.ShowHistory = history; Save(); }
        var timer = config.EnablePullTimer;
        if (ImGui.Checkbox("Enable 7:54 pull-timer fallback", ref timer)) { config.EnablePullTimer = timer; Save(); }

        var scale = config.TextScale;
        if (ImGui.SliderFloat("Text scale", ref scale, 0.8f, 2.5f, "%.2f")) { config.TextScale = scale; Save(); }
        var opacity = config.BackgroundOpacity;
        if (ImGui.SliderFloat("Background opacity", ref opacity, 0.1f, 1f, "%.2f")) { config.BackgroundOpacity = opacity; Save(); }

        ImGui.Spacing();
        if (ImGui.Button("Preview overlay")) PreviewRole();
        ImGui.SameLine();
        if (ImGui.Button("Clear now")) plugin.Engine.Reset();
        ImGui.SameLine();
        if (ImGui.Button("Unlock overlay")) { config.Locked = false; Save(); }

        ImGui.Separator();
        ImGui.TextWrapped("Commands: /dmuhelper, /dmuhelper test, /dmuclear");
        ImGui.TextDisabled($"Diagnostic: {plugin.Engine.Diagnostic}");
        if (config.ShowHistory)
        {
            ImGui.Text("Recent callouts:");
            foreach (var line in plugin.Engine.History) ImGui.BulletText(line);
        }
        ImGui.Spacing();
        ImGui.TextWrapped("This plugin never moves your character, presses actions, places markers, or sends game inputs.");
    }

    private void Save() => config.Save();

    private void PreviewRole()
    {
        var (headline, detail) = config.Assignment switch
        {
            RaidRole.MainTank => ("MT: FIRE NORTH LEFT", "GNB — tank fire spot left of the north stack"),
            RaidRole.OffTank => ("OT: WATER STACK NORTH", "PLD — stack on the wind crystal"),
            RaidRole.Healer1 => ("H1: FIRE WEST", "Relative-west static spot"),
            RaidRole.Healer2 => ("H2: WATER EAST — SPREAD", "Relative-east static spot"),
            RaidRole.Dps1 => ("D1: FIRE NORTH RIGHT", "Melee fire spot right of the north stack"),
            RaidRole.Dps2 => ("D2: WATER STACK NORTH", "Melee group on the wind crystal"),
            RaidRole.Dps3 => ("D3: BAIT UMBRA SOUTH", "Return to Exdeath when the cast starts"),
            RaidRole.Dps4 => ("D4: WATER EAST — SPREAD", "Relative-east static spot"),
            _ => ("SELECT YOUR RAID ROLE", "Choose MT, OT, H1, H2, or D1–D4 in Settings"),
        };
        plugin.Engine.Set(headline, detail, 15);
    }

    private static string RoleLabel(RaidRole role) => role switch
    {
        RaidRole.MainTank => "MT — Main Tank (GNB)",
        RaidRole.OffTank => "OT — Off Tank (PLD)",
        RaidRole.Healer1 => "H1 — Healer 1",
        RaidRole.Healer2 => "H2 — Healer 2",
        RaidRole.Dps1 => "D1 — Melee 1",
        RaidRole.Dps2 => "D2 — Melee 2",
        RaidRole.Dps3 => "D3 — Ranged 1",
        RaidRole.Dps4 => "D4 — Ranged 2",
        _ => "Select a raid role…",
    };
}
