using System;
using System.Collections.Generic;
using System.Linq;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using Lumina.Excel.Sheets;

namespace DmuTankHelper;

public sealed class CalloutEngine
{
    private readonly Configuration config;
    private readonly Dictionary<string, HashSet<uint>> statusIds = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<uint, string> actionNames = new();
    private readonly HashSet<string> activeCastKeys = new();
    private DateTime? combatStarted;
    private DateTime? expiresAt;
    private bool pullWarned;
    private bool hadCombat;
    private bool bowelsActive;
    private bool personalDebuffsSeen;
    private bool secondResolution;
    private int thunderCount;
    private string lastCast = "";

    public string Current { get; private set; } = "";
    public string Detail { get; private set; } = "";
    public IReadOnlyList<string> History => history;
    public string Diagnostic { get; private set; } = "Waiting for combat";
    public double? Countdown => expiresAt is null ? null : Math.Max(0, (expiresAt.Value - DateTime.UtcNow).TotalSeconds);
    private readonly List<string> history = new();

    public CalloutEngine(Configuration config)
    {
        this.config = config;
        ResolveGameData();
    }

    private void ResolveGameData()
    {
        var wantedStatuses = new[] { "Entropy", "Dynamic Fluid", "Tailwind", "Headwind" };
        foreach (var row in Plugin.DataManager.GetExcelSheet<Status>())
        {
            var name = row.Name.ToString();
            if (wantedStatuses.Contains(name, StringComparer.OrdinalIgnoreCase))
            {
                if (!statusIds.TryGetValue(name, out var ids)) statusIds[name] = ids = new HashSet<uint>();
                ids.Add(row.RowId);
            }
        }

        var wantedActions = new[] { "Bowels of Agony", "Thunder III", "Longitudinal Implosion", "Latitudinal Implosion", "Umbra Smash", "Vacuum Wave", "The Decisive Battle", "Definition of Insanity" };
        foreach (var row in Plugin.DataManager.GetExcelSheet<Lumina.Excel.Sheets.Action>())
        {
            var name = row.Name.ToString();
            if (wantedActions.Contains(name, StringComparer.OrdinalIgnoreCase)) actionNames[row.RowId] = name;
        }
        Plugin.Log.Information("Resolved {StatusCount} DMU statuses and {ActionCount} actions.", statusIds.Count, actionNames.Count);
    }

    public void Update()
    {
        var inCombat = Plugin.Condition[ConditionFlag.InCombat];
        if (inCombat && !hadCombat)
        {
            combatStarted = DateTime.UtcNow;
            pullWarned = false;
            Diagnostic = "Combat timer started";
        }
        else if (!inCombat && hadCombat)
        {
            Reset("Combat ended");
        }
        hadCombat = inCombat;

        if (inCombat && PartyIsDead()) Reset("Party wipe detected");

        if (inCombat && config.EnablePullTimer && combatStarted is not null && !pullWarned)
        {
            var elapsed = (DateTime.UtcNow - combatStarted.Value).TotalSeconds;
            if (elapsed >= config.PullWarningSeconds)
            {
                pullWarned = true;
                if (config.Assignment == RaidRole.MainTank)
                    Set("GO TO EXDEATH", "RAMPART + CAMO + CORUNDUM — TAKE HIT 1", 8);
                else if (config.Assignment == RaidRole.OffTank)
                    Set("PREPARE AT EXDEATH", "MT TAKES HIT 1 — YOU TAKE HIT 2", 10);
                else
                    Set("TANKBUSTERS SOON", "STAY CLEAR — USE ASSIGNED PARTY MITIGATION", 8);
            }
        }

        ScanCasts();
        ScanPersonalDebuffs();

        if (expiresAt is not null && DateTime.UtcNow >= expiresAt && !bowelsActive)
        {
            Current = "";
            Detail = "";
            expiresAt = null;
        }
    }

    private bool PartyIsDead()
    {
        if (Plugin.PartyList.Length < 2) return false;
        var found = 0;
        var dead = 0;
        foreach (var member in Plugin.PartyList)
        {
            found++;
            if (member.CurrentHP == 0) dead++;
        }
        return found >= 2 && found == dead;
    }

    private void ScanCasts()
    {
        var castingNow = new HashSet<string>();
        foreach (var obj in Plugin.ObjectTable)
        {
            if (obj is not IBattleChara battle || !battle.IsCasting) continue;
            var boss = obj.Name.ToString();
            if (!boss.Equals("Exdeath", StringComparison.OrdinalIgnoreCase) && !boss.Equals("Chaos", StringComparison.OrdinalIgnoreCase) && !boss.Equals("Kefka", StringComparison.OrdinalIgnoreCase)) continue;
            if (!actionNames.TryGetValue(battle.CastActionId, out var action)) continue;
            var key = $"{obj.EntityId:X}:{battle.CastActionId}";
            castingNow.Add(key);
            lastCast = $"{boss}: {action}";
            Diagnostic = lastCast;
            if (!activeCastKeys.Add(key)) continue;
            OnCast(action, boss, battle.TotalCastTime - battle.CurrentCastTime);
        }
        activeCastKeys.RemoveWhere(key => !castingNow.Contains(key));
    }

    private void OnCast(string action, string boss, float remaining)
    {
        switch (action)
        {
            case "Definition of Insanity":
                bowelsActive = false;
                personalDebuffsSeen = false;
                secondResolution = false;
                thunderCount = 0;
                Set(OpeningHeadline(), OpeningDetail(), 8);
                break;
            case "Bowels of Agony":
                bowelsActive = true;
                personalDebuffsSeen = false;
                secondResolution = false;
                thunderCount = 0;
                Set(BowelsHeadline(), BowelsDetail(), Math.Max(8, remaining + 4));
                break;
            case "Thunder III":
                if (!bowelsActive) break;
                thunderCount++;
                if (thunderCount == 1)
                {
                    Set(FirstResolutionHeadline(), FirstResolutionDetail(), Math.Max(7, remaining + 4));
                }
                else if (thunderCount == 2)
                {
                    if (config.Assignment == RaidRole.MainTank)
                        Set("TAKE HIT 1", "BE CLOSEST TO EXDEATH — THEN MOVE OUT", Math.Max(5, remaining + 4));
                    else if (config.Assignment == RaidRole.OffTank)
                        Set("WAIT FOR HIT 1", "THEN MOVE CLOSEST — TAKE HIT 2", Math.Max(7, remaining + 5));
                    else
                        Set("TANKBUSTER — STAY CLEAR", "LET MT/OT HANDLE THE TWO HITS", Math.Max(7, remaining + 5));
                }
                break;
            case "Longitudinal Implosion":
                secondResolution = true;
                Set("SIDES SAFE FIRST", $"THEN FRONT / BACK — {SecondResolutionText()}", Math.Max(8, remaining + 5));
                break;
            case "Latitudinal Implosion":
                secondResolution = true;
                Set("FRONT / BACK SAFE FIRST", $"THEN SIDES — {SecondResolutionText()}", Math.Max(8, remaining + 5));
                break;
            case "Umbra Smash":
                Set(UmbraHeadline(), UmbraDetail(), Math.Max(6, remaining + 3));
                break;
            case "Vacuum Wave":
                var facing = PersonalStatus("Tailwind") ? "FACE EXDEATH" : PersonalStatus("Headwind") ? "FACE AWAY FROM EXDEATH" : "CHECK WIND DEBUFF";
                var lb = config.ResponsibleForLb3 ? "LB3 ON ‘W’ — " : "";
                Set("STACK SOUTH OF EXDEATH", $"{lb}NO ANTI-KB — {facing}", Math.Max(8, remaining + 5));
                bowelsActive = false;
                break;
        }
    }

    private void ScanPersonalDebuffs()
    {
        if (!bowelsActive || LocalPlayer() is not IBattleChara player) return;
        var entropy = FindStatus(player, "Entropy");
        var fluid = FindStatus(player, "Dynamic Fluid");
        if (entropy is null && fluid is null && !personalDebuffsSeen && !PartyElementalDebuffsPresent()) return;

        if (!personalDebuffsSeen)
        {
            personalDebuffsSeen = true;
            if (entropy is not null)
            {
                var order = entropy.Value < 30 ? "FIRST" : "SECOND";
                Set($"{order}: {FirePosition()}", FireDetail(), 12);
            }
            else if (fluid is not null)
            {
                var order = fluid.Value < 30 ? "FIRST" : "SECOND";
                Set($"{order}: {WaterPosition()}", WaterDetail(), 12);
            }
            else Set(DefaultFirstPosition(), "No personal fire/water — hold your assigned bait or stack", 10);
        }

        if (secondResolution && entropy is not null && entropy.Value < 12)
            Set($"SECOND: {FirePosition()}", FireDetail(), 8, dedupe: true);
        else if (secondResolution && fluid is not null && fluid.Value < 12)
            Set($"SECOND: {WaterPosition()}", WaterDetail(), 8, dedupe: true);
    }

    private float? FindStatus(IBattleChara player, string name)
    {
        if (!statusIds.TryGetValue(name, out var ids)) return null;
        foreach (var status in player.StatusList)
            if (ids.Contains(status.StatusId)) return status.RemainingTime;
        return null;
    }

    private IBattleChara? LocalPlayer()
    {
        if (!Plugin.PlayerState.IsLoaded) return null;
        foreach (var obj in Plugin.ObjectTable)
            if (obj.EntityId == Plugin.PlayerState.EntityId) return obj as IBattleChara;
        return null;
    }

    private bool PersonalStatus(string name) => LocalPlayer() is { } player && FindStatus(player, name) is not null;

    public void Set(string headline, string detail, double seconds, bool dedupe = false)
    {
        if (dedupe && Current == headline) return;
        Current = headline;
        Detail = detail;
        expiresAt = DateTime.UtcNow.AddSeconds(seconds);
        var line = string.IsNullOrWhiteSpace(detail) ? headline : $"{headline} — {detail}";
        if (history.Count == 0 || history[0] != line) history.Insert(0, line);
        if (history.Count > 8) history.RemoveAt(history.Count - 1);
    }

    public void Reset(string reason = "Manual clear")
    {
        Current = "";
        Detail = "";
        expiresAt = null;
        combatStarted = null;
        pullWarned = false;
        bowelsActive = false;
        personalDebuffsSeen = false;
        secondResolution = false;
        thunderCount = 0;
        activeCastKeys.Clear();
        history.Clear();
        Diagnostic = reason + (string.IsNullOrEmpty(lastCast) ? "" : $"; last cast {lastCast}");
    }

    private bool PartyElementalDebuffsPresent()
    {
        foreach (var member in Plugin.PartyList)
            if (member.GameObject is IBattleChara battle && (FindStatus(battle, "Entropy") is not null || FindStatus(battle, "Dynamic Fluid") is not null)) return true;
        return false;
    }

    private string FirstResolutionHeadline()
    {
        var player = LocalPlayer();
        if (player is null) return "RESOLVE FIRST DEBUFF";
        var entropy = FindStatus(player, "Entropy");
        var fluid = FindStatus(player, "Dynamic Fluid");
        if (entropy is < 30) return $"FIRST: {FirePosition()}";
        if (fluid is < 30) return $"FIRST: {WaterPosition()}";
        return DefaultFirstPosition();
    }

    private string FirstResolutionDetail()
    {
        var player = LocalPlayer();
        if (player is null) return "Use relative Wind north";
        var entropy = FindStatus(player, "Entropy");
        var fluid = FindStatus(player, "Dynamic Fluid");
        if (entropy is < 30) return FireDetail();
        if (fluid is < 30) return WaterDetail();
        return "No short debuff — hold assigned position";
    }

    private string SecondResolutionText()
    {
        var player = LocalPlayer();
        if (player is null) return "PREPARE SECOND DEBUFF";
        if (FindStatus(player, "Entropy") is not null) return $"THEN {FirePosition()}";
        if (FindStatus(player, "Dynamic Fluid") is not null) return $"THEN {WaterPosition()}";
        return "THEN HOLD ASSIGNED POSITION";
    }

    private string OpeningHeadline() => config.Assignment switch
    {
        RaidRole.MainTank => "PREPARE: TANK CHAOS",
        RaidRole.OffTank => "PREPARE: TANK EXDEATH",
        RaidRole.Healer1 or RaidRole.Dps1 or RaidRole.Dps2 => "ALPHA GROUP",
        RaidRole.Healer2 or RaidRole.Dps3 or RaidRole.Dps4 => "BETA GROUP",
        _ => "SELECT YOUR RAID ROLE",
    };

    private string OpeningDetail() => config.Assignment switch
    {
        RaidRole.Healer1 or RaidRole.Dps1 or RaidRole.Dps2 => "ALPHA: BAIT TO HIT CHAOS ONLY",
        RaidRole.Healer2 or RaidRole.Dps3 or RaidRole.Dps4 => "BETA: BAIT TO HIT EXDEATH ONLY",
        _ => "Wind becomes relative north",
    };

    private string BowelsHeadline() => config.Assignment switch
    {
        RaidRole.MainTank => "PULL CHAOS TO WIND",
        RaidRole.OffTank => "KEEP EXDEATH CENTER",
        RaidRole.Healer1 or RaidRole.Dps3 => "GO RELATIVE WEST",
        RaidRole.Healer2 or RaidRole.Dps4 => "GO RELATIVE EAST",
        RaidRole.Dps1 or RaidRole.Dps2 => "STACK RELATIVE NORTH",
        _ => "READ YOUR DEBUFFS",
    };

    private string BowelsDetail() => config.Assignment switch
    {
        RaidRole.Healer1 or RaidRole.Dps3 => "WEST CRYSTAL BAIT — THEN READ FIRE/WATER",
        RaidRole.Healer2 or RaidRole.Dps4 => "EAST CRYSTAL BAIT — THEN READ FIRE/WATER",
        RaidRole.Dps1 or RaidRole.Dps2 => "MELEE GROUP — THEN READ FIRE/WATER",
        _ => "Reading your debuffs…",
    };

    private string UmbraHeadline() => config.Assignment switch
    {
        RaidRole.MainTank => "KEEP CHAOS CENTER",
        RaidRole.OffTank => "PULL EXDEATH TO WIND",
        RaidRole.Dps3 => "BAIT UMBRA SOUTH EDGE",
        _ => "MOVE TO EXDEATH",
    };

    private string UmbraDetail() => config.Assignment == RaidRole.Dps3
        ? "RETURN TO EXDEATH WHEN THE CAST STARTS"
        : "STACK AT EXDEATH NEXT";

    private string FirePosition() => config.Assignment switch
    {
        RaidRole.MainTank or RaidRole.OffTank => "FIRE NORTH LEFT",
        RaidRole.Dps1 or RaidRole.Dps2 => "FIRE NORTH RIGHT",
        RaidRole.Healer1 or RaidRole.Dps3 => "FIRE WEST",
        RaidRole.Healer2 or RaidRole.Dps4 => "FIRE EAST",
        _ => "FIRE — CHECK ROLE",
    };

    private string FireDetail() => config.Assignment switch
    {
        RaidRole.MainTank or RaidRole.OffTank => "Tank fire spot left of the north stack",
        RaidRole.Dps1 or RaidRole.Dps2 => "Melee fire spot right of the north stack",
        RaidRole.Healer1 or RaidRole.Dps3 => "Resolve at the relative-west static spot",
        RaidRole.Healer2 or RaidRole.Dps4 => "Resolve at the relative-east static spot",
        _ => "Use the fire spot assigned to your role",
    };

    private string WaterPosition() => config.Assignment switch
    {
        RaidRole.MainTank or RaidRole.OffTank or RaidRole.Dps1 or RaidRole.Dps2 => "WATER STACK NORTH",
        RaidRole.Healer1 or RaidRole.Dps3 => "WATER WEST — SPREAD",
        RaidRole.Healer2 or RaidRole.Dps4 => "WATER EAST — SPREAD",
        _ => "WATER — CHECK ROLE",
    };

    private string WaterDetail() => config.Assignment switch
    {
        RaidRole.MainTank or RaidRole.OffTank or RaidRole.Dps1 or RaidRole.Dps2 => "Melee/tank stack on the wind crystal",
        RaidRole.Healer1 or RaidRole.Dps3 => "Relative-west static spot; do not overlap the other bait",
        RaidRole.Healer2 or RaidRole.Dps4 => "Relative-east static spot; do not overlap the other bait",
        _ => "Use the water spot assigned to your role",
    };

    private string DefaultFirstPosition() => config.Assignment switch
    {
        RaidRole.Healer1 or RaidRole.Dps3 => "HOLD RELATIVE WEST",
        RaidRole.Healer2 or RaidRole.Dps4 => "HOLD RELATIVE EAST",
        RaidRole.MainTank or RaidRole.OffTank or RaidRole.Dps1 or RaidRole.Dps2 => "STACK RELATIVE NORTH",
        _ => "HOLD ASSIGNED POSITION",
    };
}
