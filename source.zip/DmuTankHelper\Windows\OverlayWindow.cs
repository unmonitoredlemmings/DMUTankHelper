using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;

namespace DmuTankHelper.Windows;

public sealed class OverlayWindow : Window
{
    private readonly Plugin plugin;

    public OverlayWindow(Plugin plugin) : base("DMU Tank Helper###DmuTankHelperOverlay")
    {
        this.plugin = plugin;
        SizeConstraints = new WindowSizeConstraints { MinimumSize = new Vector2(330, 92), MaximumSize = new Vector2(900, 500) };
        RespectCloseHotkey = false;
    }

    public override bool DrawConditions()
    {
        if (!IsOpen) IsOpen = true;
        return !plugin.Configuration.HideWhenIdle || !string.IsNullOrWhiteSpace(plugin.Engine.Current);
    }

    public override void PreDraw()
    {
        Flags = ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse | ImGuiWindowFlags.NoCollapse;
        if (plugin.Configuration.Locked) Flags |= ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoInputs | ImGuiWindowFlags.NoTitleBar;
        BgAlpha = plugin.Configuration.BackgroundOpacity;
    }

    public override void Draw()
    {
        var scale = plugin.Configuration.TextScale;
        ImGui.SetWindowFontScale(scale);
        var headline = string.IsNullOrWhiteSpace(plugin.Engine.Current) ? "DMU Tank Helper ready" : plugin.Engine.Current;
        var color = HeadlineColor(headline);
        CenteredText(headline, color);
        if (!string.IsNullOrWhiteSpace(plugin.Engine.Detail)) CenteredText(plugin.Engine.Detail, new Vector4(1f, 1f, 1f, 1f));
        if (plugin.Engine.Countdown is > 0 and var seconds) CenteredText($"{seconds:0.0}s", new Vector4(1f, .82f, .2f, 1f));
        ImGui.SetWindowFontScale(1f);

        if (!plugin.Configuration.Locked)
        {
            ImGui.Separator();
            if (ImGui.SmallButton("Clear")) plugin.Engine.Reset();
            ImGui.SameLine();
            if (ImGui.SmallButton("Settings")) plugin.ToggleConfig();
            ImGui.SameLine();
            ImGui.TextDisabled("Drag this window, then lock it in Settings");
        }
    }

    private static Vector4 HeadlineColor(string text)
    {
        if (text.Contains("HIT", StringComparison.OrdinalIgnoreCase) || text.Contains("LB3", StringComparison.OrdinalIgnoreCase)) return new Vector4(1f, .35f, .25f, 1f);
        if (text.Contains("FIRE", StringComparison.OrdinalIgnoreCase)) return new Vector4(1f, .45f, .22f, 1f);
        if (text.Contains("WIND", StringComparison.OrdinalIgnoreCase)) return new Vector4(.3f, 1f, .62f, 1f);
        return new Vector4(1f, .9f, .25f, 1f);
    }

    private static void CenteredText(string text, Vector4 color)
    {
        var width = ImGui.CalcTextSize(text).X;
        ImGui.SetCursorPosX(Math.Max(ImGui.GetCursorPosX(), (ImGui.GetWindowSize().X - width) / 2));
        ImGui.TextColored(color, text);
    }
}
