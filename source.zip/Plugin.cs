using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using DmuTankHelper.Windows;

namespace DmuTankHelper;

public sealed class Plugin : IDalamudPlugin
{
    [PluginService] internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    [PluginService] internal static ICommandManager CommandManager { get; private set; } = null!;
    [PluginService] internal static IClientState ClientState { get; private set; } = null!;
    [PluginService] internal static IPlayerState PlayerState { get; private set; } = null!;
    [PluginService] internal static IDataManager DataManager { get; private set; } = null!;
    [PluginService] internal static IObjectTable ObjectTable { get; private set; } = null!;
    [PluginService] internal static IPartyList PartyList { get; private set; } = null!;
    [PluginService] internal static ICondition Condition { get; private set; } = null!;
    [PluginService] internal static IFramework Framework { get; private set; } = null!;
    [PluginService] internal static IPluginLog Log { get; private set; } = null!;

    internal Configuration Configuration { get; }
    internal CalloutEngine Engine { get; }
    internal readonly WindowSystem WindowSystem = new("DmuTankHelper");
    private readonly OverlayWindow overlay;
    private readonly ConfigWindow configWindow;

    public Plugin()
    {
        Configuration = PluginInterface.GetPluginConfig() as Configuration ?? new Configuration();
        Engine = new CalloutEngine(Configuration);
        overlay = new OverlayWindow(this) { IsOpen = true };
        configWindow = new ConfigWindow(this) { IsOpen = Configuration.Assignment == RaidRole.Unset };
        WindowSystem.AddWindow(overlay);
        WindowSystem.AddWindow(configWindow);

        CommandManager.AddHandler("/dmuhelper", new CommandInfo(OnMainCommand) { HelpMessage = "Open DMU Tank Helper settings. Use '/dmuhelper test' for preview." });
        CommandManager.AddHandler("/dmuclear", new CommandInfo((_, _) => Engine.Reset()) { HelpMessage = "Clear DMU Tank Helper callouts and timeline." });
        PluginInterface.UiBuilder.Draw += WindowSystem.Draw;
        PluginInterface.UiBuilder.OpenConfigUi += ToggleConfig;
        PluginInterface.UiBuilder.OpenMainUi += ToggleConfig;
        Framework.Update += OnUpdate;
    }

    private void OnUpdate(IFramework _) => Engine.Update();

    private void OnMainCommand(string _, string args)
    {
        switch (args.Trim().ToLowerInvariant())
        {
            case "clear": Engine.Reset(); break;
            case "test": Engine.Set("GO TO EXDEATH", "RAMPART + CAMO + CORUNDUM — TAKE HIT 1", 15); break;
            default: configWindow.Toggle(); break;
        }
    }

    internal void ToggleConfig() => configWindow.Toggle();

    public void Dispose()
    {
        Framework.Update -= OnUpdate;
        PluginInterface.UiBuilder.Draw -= WindowSystem.Draw;
        PluginInterface.UiBuilder.OpenConfigUi -= ToggleConfig;
        PluginInterface.UiBuilder.OpenMainUi -= ToggleConfig;
        CommandManager.RemoveHandler("/dmuhelper");
        CommandManager.RemoveHandler("/dmuclear");
        WindowSystem.RemoveAllWindows();
    }
}
