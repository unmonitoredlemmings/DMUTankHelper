using Dalamud.Configuration;

namespace DmuTankHelper;

public enum TankAssignment { Unset, MainTank, OffTank }

[System.Serializable]
public sealed class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;
    public TankAssignment Assignment { get; set; } = TankAssignment.Unset;
    public bool ResponsibleForLb3 { get; set; } = true;
    public bool Locked { get; set; }
    public bool HideWhenIdle { get; set; } = true;
    public bool ShowHistory { get; set; } = true;
    public bool EnablePullTimer { get; set; } = true;
    public float PullWarningSeconds { get; set; } = 474f;
    public float TextScale { get; set; } = 1.35f;
    public float BackgroundOpacity { get; set; } = 0.82f;

    public void Save() => Plugin.PluginInterface.SavePluginConfig(this);
}
